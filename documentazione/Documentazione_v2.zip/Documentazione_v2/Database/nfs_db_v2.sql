-- ==============================================================================
-- 1. TABELLE INDIPENDENTI E ANAGRAFICHE BASE
-- ==============================================================================

CREATE TABLE Utente (
    id_utente INT AUTO_INCREMENT PRIMARY KEY,
    user_name VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    pw VARCHAR(255) NOT NULL,
    nome VARCHAR(50) NOT NULL,
    cognome VARCHAR(50) NOT NULL
);

CREATE TABLE Carta (
    numero_carta VARCHAR(20) PRIMARY KEY,
    data_scadenza DATE NOT NULL,
    cvv VARCHAR(4) NOT NULL
);

CREATE TABLE Indirizzo (
    via VARCHAR(100),
    civico VARCHAR(10),
    cap VARCHAR(10),
    provincia VARCHAR(50),
    citta VARCHAR(50),
    PRIMARY KEY (via, civico, cap)
);

CREATE TABLE Prodotto (
    id_prodotto INT AUTO_INCREMENT PRIMARY KEY,
    tipo VARCHAR(50) NOT NULL -- Es: 'Componente' o 'Build'
);

-- ==============================================================================
-- 2. GERARCHIA UTENTI E PRODOTTI (IS-A)
-- ==============================================================================

-- UtenteGenerico IS-A Utente
CREATE TABLE UtenteGenerico (
    id_utente INT PRIMARY KEY,
    indirizzo_via VARCHAR(100),
    indirizzo_civico VARCHAR(10),
    indirizzo_cap VARCHAR(10),
    numero_carta VARCHAR(20),
    
    FOREIGN KEY (id_utente) REFERENCES Utente(id_utente) ON DELETE CASCADE,
    FOREIGN KEY (indirizzo_via, indirizzo_civico, indirizzo_cap) REFERENCES Indirizzo(via, civico, cap),
    FOREIGN KEY (numero_carta) REFERENCES Carta(numero_carta)
);

-- Build IS-A Prodotto
CREATE TABLE Build (
    id_prodotto INT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    
    FOREIGN KEY (id_prodotto) REFERENCES Prodotto(id_prodotto) ON DELETE CASCADE
);

-- Componente IS-A Prodotto
CREATE TABLE Componente (
    id_prodotto INT PRIMARY KEY,
    marca VARCHAR(50) NOT NULL,
    modello VARCHAR(100) NOT NULL,
    tipo_componente VARCHAR(50) NOT NULL, -- Es: 'CPU', 'RAM'
    
    FOREIGN KEY (id_prodotto) REFERENCES Prodotto(id_prodotto) ON DELETE CASCADE
);

-- ==============================================================================
-- 3. RELAZIONI TRA PRODOTTI E SPECIFICHE
-- ==============================================================================

CREATE TABLE Aspetto_Tecnico (
    id_prodotto INT,
    aspetto_tecnico VARCHAR(50),
    valore VARCHAR(100),
    
    -- Chiave composta per permettere più aspetti per un singolo componente
    PRIMARY KEY (id_prodotto, aspetto_tecnico),
    FOREIGN KEY (id_prodotto) REFERENCES Componente(id_prodotto) ON DELETE CASCADE
);

-- Relazione molti-a-molti tra Build e Componente
CREATE TABLE Composizione (
    id_build INT,
    id_componente INT,
    
    PRIMARY KEY (id_build, id_componente),
    FOREIGN KEY (id_build) REFERENCES Build(id_prodotto) ON DELETE CASCADE,
    FOREIGN KEY (id_componente) REFERENCES Componente(id_prodotto) ON DELETE CASCADE
);

-- ==============================================================================
-- 4. MARKETPLACE (ORDINI E ANNUNCI)
-- ==============================================================================

-- Creiamo prima l'Ordine
CREATE TABLE Ordine (
    id_ordine INT AUTO_INCREMENT PRIMARY KEY,
    id_utente_acquirente INT NOT NULL, 
    data_ordine DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (id_utente_acquirente) REFERENCES Utente(id_utente) ON DELETE CASCADE
);

-- Annuncio con il nuovo campo "prezzo"
CREATE TABLE Annuncio (
    id_annuncio INT AUTO_INCREMENT PRIMARY KEY,
    id_utente_venditore INT NOT NULL, 
    id_prodotto INT NOT NULL,         
    prezzo DECIMAL(10,2) NOT NULL,    -- NUOVO CAMPO INSERITO
    id_ordine INT DEFAULT NULL,       -- NULL finché non viene acquistato
    
    FOREIGN KEY (id_utente_venditore) REFERENCES Utente(id_utente) ON DELETE CASCADE,
    FOREIGN KEY (id_prodotto) REFERENCES Prodotto(id_prodotto) ON DELETE CASCADE,
    FOREIGN KEY (id_ordine) REFERENCES Ordine(id_ordine) ON DELETE SET NULL 
);

-- ==============================================================================
-- 5. FORUM E CONTENUTI UTENTE (IS-A)
-- ==============================================================================

CREATE TABLE ContenutoUtente (
    id_contenutoUtente INT AUTO_INCREMENT PRIMARY KEY,
    id_utente INT NOT NULL,
    testo TEXT NOT NULL,
    data_pubblicazione DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (id_utente) REFERENCES Utente(id_utente) ON DELETE CASCADE
);

-- Post IS-A ContenutoUtente
CREATE TABLE Post (
    id_contenutoUtente INT PRIMARY KEY,
    titolo VARCHAR(150) NOT NULL,
    sottotitolo VARCHAR(150),
    
    FOREIGN KEY (id_contenutoUtente) REFERENCES ContenutoUtente(id_contenutoUtente) ON DELETE CASCADE
);

-- Commento IS-A ContenutoUtente
CREATE TABLE Commento (
    id_commento INT PRIMARY KEY, 
    id_post_riferimento INT NOT NULL,
    id_parent_riferimento INT NOT NULL,
    
    FOREIGN KEY (id_commento) REFERENCES ContenutoUtente(id_contenutoUtente) ON DELETE CASCADE,
    FOREIGN KEY (id_post_riferimento) REFERENCES Post(id_contenutoUtente) ON DELETE CASCADE,
    FOREIGN KEY (id_parent_riferimento) REFERENCES ContenutoUtente(id_contenutoUtente) ON DELETE CASCADE
);

-- ==============================================================================
-- 6. ASSISTENZA (TICKETS E MESSAGGI)
-- ==============================================================================

CREATE TABLE Ticket (
    id_ticket INT AUTO_INCREMENT PRIMARY KEY,
    id_utente_richiedente INT NOT NULL, -- UtenteGenerico
    id_utente_gestore INT,              -- Staff (può essere NULL all'inizio)
    stato VARCHAR(50) NOT NULL DEFAULT 'Aperto',
    
    FOREIGN KEY (id_utente_richiedente) REFERENCES UtenteGenerico(id_utente),
    FOREIGN KEY (id_utente_gestore) REFERENCES Utente(id_utente)
);

-- Messaggio IS-A ContenutoUtente
CREATE TABLE Messaggio (
    id_contenutoUtente INT PRIMARY KEY,
    id_ticket INT NOT NULL,
    
    FOREIGN KEY (id_contenutoUtente) REFERENCES ContenutoUtente(id_contenutoUtente) ON DELETE CASCADE,
    FOREIGN KEY (id_ticket) REFERENCES Ticket(id_ticket) ON DELETE CASCADE
);