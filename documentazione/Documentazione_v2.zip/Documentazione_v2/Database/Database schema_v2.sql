Utente(id_utente, user_name, email, pw, nome, cognome);
-- UtenteGenerico è una tabella "sottoinsieme" di utente
UtenteGenerico(id_utente(Utente), indirizzo, carta);
-- numero_carta deve essere la primary key
Carta(numero_carta, data_scadenza, cvv);
-- la combinazione di via, civico e cap devono essere primary key
Indirizzo(via, civico, cap, provincia, citta);
-- i primi due id sono foreign key riferite ad altre tabelle: il primo id_utente indica il venditore, id_prodotto indica il prodotto
-- in vendita; in caso venga acquistato, id_ordine non è più NULL
Annuncio(id_annuncio, id_utente(Utente), id_prodotto(Prodotto), prezzo, id_ordine(Ordine));
-- id_utente si riferisce all'utente acquirente che ha effettuato l'ordine
Ordine(id_ordine, id_utente(Utente), data_ordine);

-- id_prodotto è primary key
Prodotto(id_prodotto, tipo);
-- id_prodotto è foreign key
Build(id_prodotto(Prodotto), nome);
Componente(id_prodotto(Prodotto), marca, modello, tipo_componente);
-- id_prodotto è foreign key e si riferisce a componenti
Aspetto tecnico(id_prodotto(Componente), aspetto_tecnico, valore);
-- Serve a collegare una build a tutte le componenti che la compongono
Composizione(id_prodotto(Build), id_prodotto(Componente));

ContenutoUtente(id_contenutoUtente, id_utente(Utente), testo, data_pubblicazione);
-- id_contenutoUtente è foreign key
Post(id_contenutoUtente(ContenutoUtente), titolo, sottotitolo);
-- il primo id_contenutoUtente si riferisce al post di riferimento del commento, il secondo si riferisce al contenuto parent
-- quindi il post stesso oppure un altro commento
Commento(id_contenutoUtente(Post), id_contenutoUtente(ContenutoUtente));

-- id_ticket è primary key; il primo id_utente è riferito all'utenteGenerico che apre il ticket;
-- il secondo id_utente è riferito all'utente
Ticket(id_ticket, id_utente, id_utente, stato);
-- id_contenutoUtente è primary key e si riferisce al contenuto utente; id_ticket è riferito al ticket
Messaggio(id_contenutoUtente(ContenutoUtente), id_ticket(Ticket));