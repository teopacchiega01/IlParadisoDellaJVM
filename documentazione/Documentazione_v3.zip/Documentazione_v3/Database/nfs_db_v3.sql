CREATE TABLE Utente (
    --id_utente INT AUTO_INCREMENT PRIMARY KEY,
    user_name VARCHAR(50) PRIMARY KEY,
    email VARCHAR(100) UNIQUE NOT NULL,
    pw VARCHAR(255) NOT NULL,
    nome VARCHAR(50) NOT NULL,
    cognome VARCHAR(50) NOT NULL
);

CREATE TABLE Carta (
    numero_carta VARCHAR(20) PRIMARY KEY,
    data_scadenza DATE NOT NULL,
    cvv VARCHAR(3) NOT NULL
);

CREATE TABLE Indirizzo (
    id_indirizzo VARCHAR(20),
    via VARCHAR(100),
    civico VARCHAR(10),
    cap VARCHAR(5),
    provincia VARCHAR(2),
    citta VARCHAR(50),
    PRIMARY KEY (id_indirizzo)
);

CREATE TABLE Prodotto (
    id_prodotto VARCHAR(20) PRIMARY KEY,
    tipo VARCHAR(50) NOT NULL -- Es: 'COMPONENTE' o 'BUILD'
    prezzo DECIMAL(10,2) NOT NULL
);

-- UtenteGenerico IS-A Utente
CREATE TABLE UtenteGenerico (
    user_name VARCHAR(50) PRIMARY KEY,
    id_indirizzo VARCHAR(20),
    numero_carta VARCHAR(20),
    
    FOREIGN KEY (user_name) REFERENCES Utente(user_name) ON DELETE CASCADE,
    FOREIGN KEY (id_indirizzo) REFERENCES Indirizzo(id_indirizzo),
    FOREIGN KEY (numero_carta) REFERENCES Carta(numero_carta)
);

-- Build IS-A Prodotto
CREATE TABLE Build (
    id_prodotto VARCHAR(20) PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    
    FOREIGN KEY (id_prodotto) REFERENCES Prodotto(id_prodotto) ON DELETE CASCADE
);

-- Componente IS-A Prodotto
CREATE TABLE Componente (
    id_prodotto VARCHAR(20) PRIMARY KEY,
    marca VARCHAR(50) NOT NULL,
    modello VARCHAR(100) NOT NULL,
    tipo_componente VARCHAR(10) NOT NULL, -- Es: 'CPU', 'RAM', 'GPU', 'MOBO','PSU'
    potenza_richiesta INT NOT NULL
    
    FOREIGN KEY (id_prodotto) REFERENCES Prodotto(id_prodotto) ON DELETE CASCADE
);

CREATE TABLE Aspetto_Tecnico (
    id_prodotto VARCHAR(20),
    aspetto_tecnico VARCHAR(50),
    valore VARCHAR(100),
    
    PRIMARY KEY (id_prodotto, aspetto_tecnico),
    FOREIGN KEY (id_prodotto) REFERENCES Componente(id_prodotto) ON DELETE CASCADE
);

-- Relazione molti-a-molti tra Build e Componente
CREATE TABLE Composizione (
    id_build VARCHAR(20),
    id_componente VARCHAR(20),
    
    PRIMARY KEY (id_build, id_componente),
    FOREIGN KEY (id_build) REFERENCES Build(id_prodotto) ON DELETE CASCADE,
    FOREIGN KEY (id_componente) REFERENCES Componente(id_prodotto) ON DELETE CASCADE
);

CREATE TABLE Ordine (
    id_ordine VARCHAR(10) PRIMARY KEY,
    id_utente_acquirente VARCHAR(50) NOT NULL, 
    data_ordine DATETIME DEFAULT CURRENT_TIMESTAMP,
    prezzo DECIMAL(10,2) NOT NULL,
    
    FOREIGN KEY (id_utente_acquirente) REFERENCES Utente(user_name) ON DELETE CASCADE
);

CREATE TABLE Annuncio (
    id_annuncio VARCHAR(20) PRIMARY KEY,
    id_utente_venditore VARCHAR(20) NOT NULL, 
    id_prodotto VARCHAR(20) NOT NULL,         
    prezzo DECIMAL(10,2) NOT NULL,    
    id_ordine VARCHAR(10) DEFAULT NULL,       -- NULL finché non viene acquistato
    
    FOREIGN KEY (id_utente_venditore) REFERENCES Utente(user_name) ON DELETE CASCADE,
    FOREIGN KEY (id_prodotto) REFERENCES Prodotto(id_prodotto) ON DELETE CASCADE,
    FOREIGN KEY (id_ordine) REFERENCES Ordine(id_ordine) ON DELETE SET NULL 
);

CREATE TABLE ContenutoUtente (
    id_contenutoUtente VARCHAR(10) PRIMARY KEY,
    id_utente VARCHAR(50) NOT NULL,
    testo TEXT NOT NULL,
    data_pubblicazione DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (id_utente) REFERENCES Utente(user_name) ON DELETE CASCADE
);

-- Post IS-A ContenutoUtente
CREATE TABLE Post (
    id_contenutoUtente VARCHAR(10) PRIMARY KEY,
    titolo VARCHAR(150) NOT NULL,
    sottotitolo VARCHAR(150),
    
    FOREIGN KEY (id_contenutoUtente) REFERENCES ContenutoUtente(id_contenutoUtente) ON DELETE CASCADE
);

-- Commento IS-A ContenutoUtente
CREATE TABLE Commento (
    id_commento VARCHAR(10) PRIMARY KEY, 
    id_post_riferimento VARCHAR(10) NOT NULL,
    id_contenuto_parent VARCHAR(10) NOT NULL,
    
    FOREIGN KEY (id_commento) REFERENCES ContenutoUtente(id_contenutoUtente) ON DELETE CASCADE,
    FOREIGN KEY (id_post_riferimento) REFERENCES Post(id_contenutoUtente) ON DELETE CASCADE,
    FOREIGN KEY (id_contenuto_parent) REFERENCES ContenutoUtente(id_contenutoUtente) ON DELETE CASCADE
);

CREATE TABLE Ticket (
    id_ticket VARCHAR(18) PRIMARY KEY,
    id_utente_richiedente VARCHAR(50) NOT NULL, -- UtenteGenerico
    id_utente_gestore VARCHAR(50),              -- Staff (può essere NULL all'inizio)
    stato VARCHAR(50) NOT NULL DEFAULT 'Aperto',
    
    FOREIGN KEY (id_utente_richiedente) REFERENCES UtenteGenerico(user_name),
    FOREIGN KEY (id_utente_gestore) REFERENCES Utente(user_name)
);

-- Messaggio IS-A ContenutoUtente
CREATE TABLE Messaggio (
    id_contenutoUtente VARCHAR(10) PRIMARY KEY,
    id_ticket VARCHAR(18) NOT NULL,
    
    FOREIGN KEY (id_contenutoUtente) REFERENCES ContenutoUtente(id_contenutoUtente) ON DELETE CASCADE,
    FOREIGN KEY (id_ticket) REFERENCES Ticket(id_ticket) ON DELETE CASCADE
);