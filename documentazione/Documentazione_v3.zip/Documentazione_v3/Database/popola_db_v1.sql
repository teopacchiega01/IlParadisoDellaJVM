-- ==========================================
-- TABELLA PRODOTTO (Tutti di tipo 'COMPONENTE')
-- ==========================================

INSERT INTO Prodotto (id_prodotto, tipo, prezzo) VALUES 
-- CPU
('CPUAMD007800X_000001', 'COMPONENTE', 399.99),
('CPUINTEL11900_000002', 'COMPONENTE', 450.00),
('CPUAMD005600X_000003', 'COMPONENTE', 199.50),

-- MOBO
('MOBASUS0ROGB6_000004', 'COMPONENTE', 250.00),
('MOBMSI00MAGB5_000005', 'COMPONENTE', 140.00),
('MOBGIGABZ5900_000006', 'COMPONENTE', 210.00),

-- RAM
('RAMCORSRVENGE_000007', 'COMPONENTE', 130.00),
('RAMKINGSFURY0_000008', 'COMPONENTE', 75.00),
('RAMCRUCLBASIC_000009', 'COMPONENTE', 35.00),

-- GPU
('GPUNVIDIR4090_000010', 'COMPONENTE', 1800.00),
('GPUAMD00RX790_000011', 'COMPONENTE', 999.00),
('GPUNVIDIR3060_000012', 'COMPONENTE', 300.00),

-- PSU
('PSUCORSRRM850_000013', 'COMPONENTE', 140.00),
('PSUSEASOFOCUS_000014', 'COMPONENTE', 180.00),
('PSUEVGA0SUPER_000015', 'COMPONENTE', 110.00);


-- ==========================================
-- TABELLA COMPONENTE (Con marca, modello, tipo_componente e potenza)
-- ==========================================

-- CPU
INSERT INTO Componente (id_prodotto, marca, modello, tipo_componente, potenza_richiesta) VALUES 
('CPUAMD007800X_000001', 'AMD', 'Ryzen 7 7800X', 'CPU', 120),
('CPUINTEL11900_000002', 'Intel', 'Core i9 11900K', 'CPU', 125),
('CPUAMD005600X_000003', 'AMD', 'Ryzen 5 5600X', 'CPU', 65);

-- SCHEDE MADRI
INSERT INTO Componente (id_prodotto, marca, modello, tipo_componente, potenza_richiesta) VALUES 
('MOBASUS0ROGB6_000004', 'ASUS', 'ROG Strix B650', 'MOBO', 40),
('MOBMSI00MAGB5_000005', 'MSI', 'MAG B550', 'MOBO', 35),
('MOBGIGABZ5900_000006', 'Gigabyte', 'Z590 Vision', 'MOBO', 45);

-- RAM
INSERT INTO Componente (id_prodotto, marca, modello, tipo_componente, potenza_richiesta) VALUES 
('RAMCORSRVENGE_000007', 'Corsair', 'Vengeance DDR5', 'RAM', 5),
('RAMKINGSFURY0_000008', 'Kingston', 'Fury Beast DDR4', 'RAM', 5),
('RAMCRUCLBASIC_000009', 'Crucial', 'Basics DDR3', 'RAM', 4);

-- GPU
INSERT INTO Componente (id_prodotto, marca, modello, tipo_componente, potenza_richiesta) VALUES 
('GPUNVIDIR4090_000010', 'NVIDIA', 'RTX 4090', 'GPU', 450),
('GPUAMD00RX790_000011', 'AMD', 'Radeon RX 7900 XTX', 'GPU', 355),
('GPUNVIDIR3060_000012', 'NVIDIA', 'RTX 3060', 'GPU', 170),
('GPUBAGECGBARA_000099', 'BAGECORP', 'GTX BARACCA', 'GPU', 67);

-- PSU
INSERT INTO Componente (id_prodotto, marca, modello, tipo_componente, potenza_richiesta) VALUES 
('PSUCORSRRM850_000013', 'Corsair', 'RM850x', 'PSU', 850),
('PSUSEASOFOCUS_000014', 'Seasonic', 'Focus GX-1000', 'PSU', 1000),
('PSUEVGA0SUPER_000015', 'EVGA', 'SuperNOVA 750', 'PSU', 750);

-- ==========================================
-- TABELLA ASPETTO TECNICO
-- ==========================================

-- CPU 1 (AMD AM5)
INSERT INTO Aspetto_Tecnico (id_prodotto, aspetto_tecnico, valore) VALUES 
('CPUAMD007800X_000001', 'FREQUENZA_CLOCK_CPU', '4.2 GHz'),
('CPUAMD007800X_000001', 'SOCKET_CPU', 'AM5');

-- CPU 2 (Intel LGA 1200)
INSERT INTO Aspetto_Tecnico (id_prodotto, aspetto_tecnico, valore) VALUES 
('CPUINTEL11900_000002', 'FREQUENZA_CLOCK_CPU', '3.5 GHz'),
('CPUINTEL11900_000002', 'SOCKET_CPU', 'LGA_1200');

-- CPU 3 (AMD AM4)
INSERT INTO Aspetto_Tecnico (id_prodotto, aspetto_tecnico, valore) VALUES 
('CPUAMD005600X_000003', 'FREQUENZA_CLOCK_CPU', '3.7 GHz'),
('CPUAMD005600X_000003', 'SOCKET_CPU', 'AM4');

-- MOBO 1 (ATX, AM5)
INSERT INTO Aspetto_Tecnico (id_prodotto, aspetto_tecnico, valore) VALUES 
('MOBASUS0ROGB6_000004', 'FORM_FACTOR_MOBO', 'ATX'),
('MOBASUS0ROGB6_000004', 'SOCKET_CPU', 'AM5'),
('MOBASUS0ROGB6_000004', 'TIPO_SLOT_PCIE', 'PCI_EXPRESS_50'),
('MOBASUS0ROGB6_000004', 'N_SLOT_PCIE', '3'),
('MOBASUS0ROGB6_000004', 'TIPO_RAM', 'DDR5'),
('MOBASUS0ROGB6_000004', 'N_MODULI_RAM', '3');

-- MOBO 2 (mATX, AM4)
INSERT INTO Aspetto_Tecnico (id_prodotto, aspetto_tecnico, valore) VALUES 
('MOBMSI00MAGB5_000005', 'FORM_FACTOR_MOBO', 'mATX'),
('MOBMSI00MAGB5_000005', 'SOCKET_CPU', 'AM4'),
('MOBMSI00MAGB5_000005', 'TIPO_SLOT_PCIE', 'PCI_EXPRESS_40'),
('MOBMSI00MAGB5_000005', 'N_SLOT_PCIE', '2'),
('MOBMSI00MAGB5_000005', 'TIPO_RAM', 'DDR4'),
('MOBMSI00MAGB5_000005', 'N_MODULI_RAM', '4');

-- MOBO 3 (ITX, LGA 1200)
INSERT INTO Aspetto_Tecnico (id_prodotto, aspetto_tecnico, valore) VALUES 
('MOBGIGABZ5900_000006', 'FORM_FACTOR_MOBO', 'ITX'),
('MOBGIGABZ5900_000006', 'SOCKET_CPU', 'LGA_1200'),
('MOBGIGABZ5900_000006', 'TIPO_SLOT_PCIE', 'PCI_EXPRESS_40'),
('MOBGIGABZ5900_000006', 'N_SLOT_PCIE', '1'),
('MOBGIGABZ5900_000006', 'TIPO_RAM', 'DDR4'),
('MOBGIGABZ5900_000006', 'N_MODULI_RAM', '4');

-- RAM 1 (DDR5)
INSERT INTO Aspetto_Tecnico (id_prodotto, aspetto_tecnico, valore) VALUES 
('RAMCORSRVENGE_000007', 'TIPO_RAM', 'DDR5'),
('RAMCORSRVENGE_000007', 'FREQUENZA', '6000 MHz'),
('RAMCORSRVENGE_000007', 'N_MODULI_RAM', '2'),
('RAMCORSRVENGE_000007', 'DIM_SINGOLO_MODULO_RAM', '16GB');

-- RAM 2 (DDR4)
INSERT INTO Aspetto_Tecnico (id_prodotto, aspetto_tecnico, valore) VALUES 
('RAMKINGSFURY0_000008', 'TIPO_RAM', 'DDR4'),
('RAMKINGSFURY0_000008', 'FREQUENZA', '3200 MHz'),
('RAMKINGSFURY0_000008', 'N_MODULI_RAM', '2'),
('RAMKINGSFURY0_000008', 'DIM_SINGOLO_MODULO_RAM', '8GB');

-- RAM 3 (DDR3)
INSERT INTO Aspetto_Tecnico (id_prodotto, aspetto_tecnico, valore) VALUES 
('RAMCRUCLBASIC_000009', 'TIPO_RAM', 'DDR3'),
('RAMCRUCLBASIC_000009', 'FREQUENZA', '1600 MHz'),
('RAMCRUCLBASIC_000009', 'N_MODULI_RAM', '1'),
('RAMCRUCLBASIC_000009', 'DIM_SINGOLO_MODULO_RAM', '8GB');

-- GPU 1 (RTX 4090: PCIe 4.0, occupa 3 slot nel case)
INSERT INTO Aspetto_Tecnico (id_prodotto, aspetto_tecnico, valore) VALUES 
('GPUNVIDIR4090_000010', 'VRAM_GB', '24'),
('GPUNVIDIR4090_000010', 'TIPO_SLOT_PCIE', 'PCI_EXPRESS_40'),
('GPUNVIDIR4090_000010', 'N_SLOT_PCIE', '3');

-- GPU 2 (RX 7900 XTX: PCIe 4.0, occupa 3 slot nel case)
INSERT INTO Aspetto_Tecnico (id_prodotto, aspetto_tecnico, valore) VALUES 
('GPUAMD00RX790_000011', 'VRAM_GB', '24'),
('GPUAMD00RX790_000011', 'TIPO_SLOT_PCIE', 'PCI_EXPRESS_40'),
('GPUAMD00RX790_000011', 'N_SLOT_PCIE', '3');

-- GPU 3 (RTX 3060: PCIe 4.0, occupa 2 slot nel case)
INSERT INTO Aspetto_Tecnico (id_prodotto, aspetto_tecnico, valore) VALUES 
('GPUNVIDIR3060_000012', 'VRAM_GB', '12'),
('GPUNVIDIR3060_000012', 'TIPO_SLOT_PCIE', 'PCI_EXPRESS_40'),
('GPUNVIDIR3060_000012', 'N_SLOT_PCIE', '2');

-- GPU 4 (GTX BARACCA)
INSERT INTO Aspetto_Tecnico (id_prodotto, aspetto_tecnico, valore) VALUES 
('GPUBAGECGBARA_000099', 'VRAM_GB', '0.512'),
('GPUBAGECGBARA_000099', 'TIPO_SLOT_PCIE', 'PCI_EXPRESS_40'),
('GPUBAGECGBARA_000099', 'N_SLOT_PCIE', '1');

-- ==========================================
-- TABELLA UTENTE
-- ==========================================
INSERT INTO Utente (user_name, email, pw, nome, cognome) VALUES
('mario_rossi88', 'mario.rossi@email.com', 'hash_pw_123', 'Mario', 'Rossi'),
('luigi_bianchi', 'luigi.bianchi@email.com', 'hash_pw_456', 'Luigi', 'Bianchi'),
('giulia_verdi', 'giulia.verdi@email.com', 'hash_pw_789', 'Giulia', 'Verdi'),
('anna_neri', 'anna.neri@email.com', 'hash_pw_012', 'Anna', 'Neri'),
('paolo_gialli', 'paolo.gialli@email.com', 'hash_pw_345', 'Paolo', 'Gialli'),
('bidello_modulare', 'paolo.limiti@gmail.com', 'password1', 'Paolo', 'Limiti'),
('tarallo_perforante', 'pietro.smusi@staff.com', '12345678', 'Pietro', 'Smusi'),
('MarioRossi99', 'mario.rossi2@email.com', 'password123', 'Mario', 'Rossi'),
('GiuliaBianchi', 'giulia.b@email.com', 'qwerty', 'Giulia', 'Bianchi'),
('AdminTech_Luca', 'admin.luca@staff.com', 'adminpass', 'Luca', 'Verdi');

-- ==========================================
-- TABELLA INDIRIZZO
-- ==========================================
INSERT INTO Indirizzo (id_indirizzo, via, civico, cap, provincia, citta) VALUES
('IND_00001', 'Via Roma', '10', '00184', 'RM', 'Roma'),
('IND_00002', 'Corso Vittorio Emanuele', '25', '20122', 'MI', 'Milano'),
('IND_00003', 'Piazza San Carlo', '4', '10121', 'TO', 'Torino'),
('IND_00004', 'Via Garibaldi', '42A', '80142', 'NA', 'Napoli'),
('IND_00005', 'Viale della Libertà', '15', '50129', 'FI', 'Firenze'),
('IND_00006', 'Via Giulio Pisa', '70', '27021', 'PV', 'Bereguardo'),
('IND_00007', 'Via Carolina Grugni', '11', '27010', 'PV', 'Filighera'),
('IND_00008', 'Via Roma', '10', '27100', 'PV', 'Pavia');

-- ==========================================
-- TABELLA CARTA
-- ==========================================
-- Le date sono nel formato standard SQL: YYYY-MM-DD
INSERT INTO Carta (numero_carta, data_scadenza, cvv) VALUES
('1111222233334444', '2028-12-31', '123'),
('5555666677778888', '2027-05-31', '456'),
('9999000011112222', '2029-10-31', '789'),
('4444555566667777', '2026-08-31', '321'),
('8888999900001111', '2030-01-31', '654'),
('4445555666677778', '2028-10-15', '825'),
('8889999000011112', '2032-02-28', '759'),
('5556666777788889', '2027-10-31', '987');

-- ==========================================
-- TABELLA UTENTE GENERICO
-- ==========================================
INSERT INTO UtenteGenerico (user_name, id_indirizzo, numero_carta) VALUES
('mario_rossi88', 'IND_00001', '1111222233334444'),
('luigi_bianchi', 'IND_00002', '5555666677778888'),
('giulia_verdi', 'IND_00003', '9999000011112222'),
('anna_neri', 'IND_00004', '4444555566667777'),
('paolo_gialli', 'IND_00005', '8888999900001111'),
('MarioRossi99', NULL, NULL),
('GiuliaBianchi', 'IND_00008', '5555666677778888');

-- ==========================================
-- TABELLA ANNUNCIO
-- ==========================================
INSERT INTO Annuncio (id_annuncio, id_utente_venditore, id_prodotto, prezzo) VALUES 
-- CPU
('ANN_0000000000000001', 'mario_rossi88', 'CPUAMD007800X_000001', 380.00),
('ANN_0000000000000002', 'giulia_verdi',  'CPUAMD007800X_000001', 350.00),
('ANN_0000000000000003', 'luigi_bianchi', 'CPUINTEL11900_000002', 420.00),
('ANN_0000000000000004', 'anna_neri',     'CPUAMD005600X_000003', 180.00),
('ANN_0000000000000005', 'paolo_gialli',  'CPUAMD005600X_000003', 150.00),

-- MOBO
('ANN_0000000000000006', 'mario_rossi88', 'MOBASUS0ROGB6_000004', 230.00),
('ANN_0000000000000007', 'luigi_bianchi', 'MOBMSI00MAGB5_000005', 120.00),
('ANN_0000000000000008', 'giulia_verdi',  'MOBMSI00MAGB5_000005', 100.00),
('ANN_0000000000000009', 'anna_neri',     'MOBGIGABZ5900_000006', 190.00),

-- RAM
('ANN_0000000000000010', 'paolo_gialli',  'RAMCORSRVENGE_000007', 115.00),
('ANN_0000000000000011', 'mario_rossi88', 'RAMCORSRVENGE_000007', 100.00),
('ANN_0000000000000012', 'luigi_bianchi', 'RAMKINGSFURY0_000008', 65.00),
('ANN_0000000000000013', 'giulia_verdi',  'RAMCRUCLBASIC_000009', 25.00),
('ANN_0000000000000014', 'anna_neri',     'RAMCRUCLBASIC_000009', 20.00),

-- GPU
('ANN_0000000000000015', 'paolo_gialli',  'GPUNVIDIR4090_000010', 1750.00),
('ANN_0000000000000016', 'mario_rossi88', 'GPUNVIDIR4090_000010', 1600.00),
('ANN_0000000000000017', 'luigi_bianchi', 'GPUAMD00RX790_000011', 900.00),
('ANN_0000000000000018', 'giulia_verdi',  'GPUNVIDIR3060_000012', 260.00),
('ANN_0000000000000019', 'anna_neri',     'GPUNVIDIR3060_000012', 220.00),

-- PSU
('ANN_0000000000000020', 'paolo_gialli',  'PSUCORSRRM850_000013', 120.00),
('ANN_0000000000000021', 'mario_rossi88', 'PSUSEASOFOCUS_000014', 150.00),
('ANN_0000000000000022', 'luigi_bianchi', 'PSUSEASOFOCUS_000014', 165.00),
('ANN_0000000000000023', 'giulia_verdi',  'PSUEVGA0SUPER_000015', 90.00);



INSERT INTO Ticket (id_ticket, id_utente_richiedente, id_utente_gestore, stato) VALUES 
('Ticket1001', 'MarioRossi99', NULL, 'IN_ASSEGNAZIONE'),
('Ticket1002', 'GiuliaBianchi', 'AdminTech_Luca', 'APERTO');


INSERT INTO ContenutoUtente (id_contenutoUtente, id_utente, testo) VALUES 
('Cont2001', 'GiuliaBianchi', 'Salve, il mio ordine risulta bloccato da tre giorni. Potete verificare?'),
('Cont2002', 'AdminTech_Luca', 'Ciao Giulia, controllo subito a sistema e ti aggiorno. Dammi 5 minuti.'),
('Cont2003', 'GiuliaBianchi', 'Perfetto, resto in attesa. Grazie mille!');


INSERT INTO Messaggio (id_contenutoUtente, id_ticket) VALUES 
('Cont2001', 'Ticket1002'),
('Cont2002', 'Ticket1002'),
('Cont2003', 'Ticket1002');


-- ==========================================
-- TABELLA CONTENUTOUTENTE (Padre di Post e Commenti)
-- ==========================================
INSERT INTO ContenutoUtente (id_contenutoUtente, id_utente, testo, data_pubblicazione) VALUES 
-- I 3 POST PRINCIPALI
('CNT_00001', 'mario_rossi88', 'Ciao a tutti, sto assemblando un PC con la RTX 4090. Quale alimentatore mi consigliate per stare tranquillo?', '2024-05-10 10:00:00'),
('CNT_00002', 'giulia_verdi', 'Ho appena montato le mie RAM Corsair DDR5 ma dal BIOS vedo che vanno solo a 4800MHz invece di 6000. Aiuto!', '2024-05-11 15:30:00'),
('CNT_00003', 'anna_neri', 'Secondo voi ha senso comprare una RX 7900 XTX ora o conviene aspettare la prossima generazione?', '2024-05-12 09:15:00'),

-- COMMENTI DIRETTI AI POST
('CNT_00004', 'luigi_bianchi', 'Vai su un Seasonic da almeno 1000W, con la 4090 non si scherza sui picchi di assorbimento.', '2024-05-10 10:15:00'), -- Commento a Post 1
('CNT_00005', 'paolo_gialli', 'Devi attivare il profilo XMP o EXPO dal BIOS, altrimenti andranno sempre alla velocità base (JEDEC).', '2024-05-11 15:45:00'), -- Commento a Post 2
('CNT_00006', 'tarallo_perforante', 'Esatto, come dice Paolo. Assicurati anche di averle messe negli slot A2 e B2 della scheda madre.', '2024-05-11 16:00:00'), -- Commento a Post 2 (Staff)
('CNT_00007', 'mario_rossi88', 'A 999 euro sul marketplace secondo me è un affare, comprala ora.', '2024-05-12 09:30:00'), -- Commento a Post 3

-- RISPOSTE AI COMMENTI (Annidati)
('CNT_00008', 'mario_rossi88', 'Grazie Luigi, ho visto il Seasonic Focus GX-1000 nel marketplace, penso prenderò quello.', '2024-05-10 10:30:00'), -- Risposta a CNT_004
('CNT_00009', 'bidello_modulare', 'Confermo, ottima scelta. Lo uso anche io sui server dello staff.', '2024-05-10 11:00:00'), -- Risposta a CNT_008 (Staff)
('CNT_00010', 'giulia_verdi', 'Ha funzionato! Grazie mille Paolo, ora vanno a 6000 fisse.', '2024-05-11 18:20:00'), -- Risposta a CNT_005
('CNT_00011', 'luigi_bianchi', 'Non sono d''accordo Mario, tra 6 mesi usciranno le nuove, perderà di valore subito.', '2024-05-12 09:45:00'), -- Risposta a CNT_007
('CNT_00012', 'mario_rossi88', 'Sì ma se si aspetta sempre non si gioca mai! 😂', '2024-05-12 09:50:00'); -- Risposta a CNT_011


-- ==========================================
-- TABELLA POST
-- ==========================================
INSERT INTO Post (id_contenutoUtente, titolo, sottotitolo) VALUES 
('CNT_00001', 'Consiglio PSU per RTX 4090', 'Dubbio su wattaggio necessario'),
('CNT_00002', 'Problema frequenza RAM DDR5', 'Le RAM non vanno alla velocità dichiarata'),
('CNT_00003', 'Acquisto RX 7900 XTX', 'Conviene adesso?');


-- ==========================================
-- TABELLA COMMENTO
-- (id_contenuto_utente, id_post_riferimento, id_parent)
-- ==========================================
INSERT INTO Commento (id_commento, id_post_riferimento, id_contenuto_parent) VALUES 
-- COMMENTI DIRETTI (Il parent è lo stesso id del post)
('CNT_00004', 'CNT_00001', 'CNT_00001'), 
('CNT_00005', 'CNT_00002', 'CNT_00002'),
('CNT_00006', 'CNT_00002', 'CNT_00002'),
('CNT_00007', 'CNT_00003', 'CNT_00003'),

-- RISPOSTE (Il parent è l'id di un altro commento)
-- Thread 1
('CNT_00008', 'CNT_00001', 'CNT_00004'), -- Mario risponde a Luigi
('CNT_00009', 'CNT_00001', 'CNT_00008'), -- Staff risponde a Mario

-- Thread 2
('CNT_00010', 'CNT_00002', 'CNT_00005'), -- Giulia risponde a Paolo

-- Thread 3
('CNT_00011', 'CNT_00003', 'CNT_00007'), -- Luigi risponde a Mario
('CNT_00012', 'CNT_00003', 'CNT_00011'); -- Mario risponde a Luigi

